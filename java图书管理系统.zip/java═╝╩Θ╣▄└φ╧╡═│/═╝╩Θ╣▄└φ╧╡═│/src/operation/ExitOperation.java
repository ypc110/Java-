package operation;

import book.BookList;

/**
 * user：ypc；
 * date：2021-04-22;
 * time: 15:51;
 */
public class ExitOperation implements IOperation{
    @Override
    public void work(BookList booklist) {
        System.out.println("退出系统");
        System.exit(0);
    }
}
