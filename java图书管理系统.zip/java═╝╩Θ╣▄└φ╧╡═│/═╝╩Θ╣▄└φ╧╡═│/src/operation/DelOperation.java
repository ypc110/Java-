package operation;

import book.Book;
import book.BookList;

import java.util.Scanner;

/**
 * user：ypc；
 * date：2021-04-22;
 * time: 15:50;
 */
public class DelOperation implements IOperation{
    @Override
    public void work(BookList booklist) {
        System.out.println("删除图书：");
        Scanner scanner  =new Scanner(System.in);
        System.out.println("请输入书名：");
        String name  = scanner.nextLine();
        int pos =-1;
        for (int i = 0; i < booklist.getSize(); i++) {
            Book book =  booklist.getBook(i);
            if(book.getName().equals(name)){
                pos = i;
                break;
            }
        }
        if(pos == -1){
            System.out.println("没有这本书");
            return;
        }
        int cur = booklist.getSize()-1;
        for(int i =pos;i<cur;i++){
            Book book = booklist.getBook(i+1);
            booklist.setBook(i,book);
        }
        booklist.setSize(cur-1);
        booklist.setBook(cur+1,null);
        System.out.println("删除成功");
    }
}
