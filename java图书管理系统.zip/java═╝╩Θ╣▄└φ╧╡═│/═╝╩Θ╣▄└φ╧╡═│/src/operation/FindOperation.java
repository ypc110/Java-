package operation;
import book.Book;
import book.BookList;
import java.util.Scanner;
/**
 * user：ypc；
 * date：2021-04-22;
 * time: 15:50;
 */
public class FindOperation implements IOperation{
    @Override

    public void work(BookList booklist) {
        System.out.println("借阅图书：");
        Scanner scanner  =new Scanner(System.in);
        System.out.println("请输入书名：");
        String name  = scanner.nextLine();
        for (int i = 0; i < booklist.getSize(); i++) {
            Book book =  booklist.getBook(i);
            if(book.getName().equals(name)){
                System.out.println("找到了这本书：");
                System.out.println(book);
                return;
            }
        }
        System.out.println("没有这本书！");
    }
}
