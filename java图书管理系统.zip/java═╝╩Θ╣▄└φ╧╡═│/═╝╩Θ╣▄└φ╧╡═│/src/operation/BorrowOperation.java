package operation;
import book.Book;
import book.BookList;
import java.util.Scanner;

/**
 * user：ypc；
 * date：2021-04-22;
 * time: 16:44;
 */
public class BorrowOperation implements IOperation {
    @Override
    public void work(BookList booklist) {
        System.out.println("借阅图书：");
        Scanner scanner  =new Scanner(System.in);
        System.out.println("请输入书名：");
        String name  = scanner.nextLine();
        for (int i = 0; i < booklist.getSize(); i++) {
            Book book =  booklist.getBook(i);
            if(book.getName().equals(name)){
               book.setBorrowed(true);
                System.out.println("借阅成功！");
                return;
            }
        }
        System.out.println("没有这本书！");
    }
}
