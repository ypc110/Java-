package operation;
import book.Book;
import book.BookList;
import java.util.Scanner;
/**
 * user：ypc；
 * date：2021-04-22;
 * time: 15:49;
 */
public class AddOperation implements IOperation {
    @Override
    public void work(BookList booklist) {
        Scanner s = new Scanner(System.in);
        Book book;
        boolean isBorrowed = false;
        System.out.println("请输入书名");
        String name = s.nextLine();
        System.out.println("请输入作者");
        String author = s.nextLine();
        System.out.println("请输入类型");
        String type = s.nextLine();
        System.out.println("请输入价格");
        int price = s.nextInt();
        book = new Book(name,author,price,type,isBorrowed);
        booklist.setBook(booklist.getSize(),book);
        booklist.setSize(booklist.getSize()+1);
        System.out.println("增加书籍成功");

    }
}
