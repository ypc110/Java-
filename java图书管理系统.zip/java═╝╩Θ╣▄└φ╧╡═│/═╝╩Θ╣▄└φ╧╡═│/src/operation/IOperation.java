package operation;
import book.*;
/**
 * user：ypc；
 * date：2021-04-22;
 * time: 15:49;
 */
public interface IOperation {
    void work(BookList booklist);
}
